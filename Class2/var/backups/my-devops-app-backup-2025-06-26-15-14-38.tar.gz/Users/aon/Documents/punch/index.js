// const sortCardArray = (cards)=>{

//   if(cards.length <= 1){
//       return cards
//   }

//   let endindex = cards.length - 1;
//   let swapped
//   const cardDatas = {
//       Jack: 9,
//       Queen: 10,
//       King: 11
//   }

//   for(let i=0; i < endindex; i++){
//       const x = cards[i];
//       const y = cards[i + 1];

//       const xValues = typeof x === 'string' ? cardDatas[x]: x;
//       const yValues = typeof y === 'string' ? cardDatas[y]: y;

//       if(xValues > yValues){
//           const temp = cards[i]
//           cards[i] = cards[i + 1]
//           cards[i] = temp
//           swapped = true
//       }

//       if(i === endindex - 1){
//           endindex--;
//           i = -1;
//       }
//       return cards

//   }

//   // using javascript inbuilt method
//   // const sortedCards =

// }

const sorTwoArray = (cards) => {
  const cardData = {
    Jack: 11,
    Queen: 12,
    King: 13,
  };

  function sortKey(card) {
    return cardData[card] || card;
  }

  // sort the card now
  cards.sort((a, b) => sortKey(a) - sortKey(b));
  return cards;
};
const cards = [2, 3, 5, 6, 8, "Queen", "Jack", "Queen", "King", "King"];
console.log(sorTwoArray(cards));
